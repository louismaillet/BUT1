# fichier de tests de la SAE 1.01 partie 1
# bilan carbone d'activités mystères en septembre 2024

# on importe toutes les fonctions et données définies dans le fichier bilan_carbone
# l'appel de ces fonctions et données doit être préfixé par bc. 
import bilan_carbone as bc  
import consultation_activites as ca


# ---------------------------------------------------------------------------------------------
# Exemples de tests à compléter impérativement
# ---------------------------------------------------------------------------------------------

def test_est_avant():
    assert bc.est_avant(('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-01', 67.2, 'type4')) == True # test avec deux tuples differents sur les types et doit retourner True
    assert bc.est_avant(('Louis', '2024-09-01', 67.2, 'type4'), ('Louis', '2024-09-01', 67.2, 'type3')) == False # test avec deux tuples differents sur les types et doit retourner False
    assert bc.est_avant(('Louis', '2024-09-01', 67.2, 'type4'), ('Louis', '2024-09-01', 67.2, 'type4')) == False # test avec deux tuples identiques et doit retourner False
    assert bc.est_avant(('Louis', '2024-09-01', 67.2, 'type4'), ('Louis', '2024-09-02', 67.1, 'type4')) == True # test avec deux tuples differents sur les dates et doit retourner True
    assert bc.est_avant(('Alexandre', '2024-09-01', 67.2, 'type4'), ('Louis', '2024-09-02', 67.2, 'type4')) == True # test avec deux tuples differents sur les prenoms et doit retourner True
    assert bc.est_avant(('Louis', '2024-09-01', 67.2, 'type4'), ('Alexendre', '2024-09-01', 67.2, 'type4')) == False # test avec deux tuples differents sur les prenoms et doit retourner False
    assert bc.est_avant(('b', '2024-09-03', 70.08, 'type3'), ('a', '2024-09-02', 67.2, 'type3')) == False # test avec deux tuples differents sur les prenoms et doit retourner False

def test_annee():
    assert bc.annee(('Louis', '2024-09-01', 67.2, 'type3')) == '2024' # test avec un tuple ('Louis', '2024-09-01', 67.2, 'type3') et doit retourner '2024'
    assert bc.annee(('Louis', '1999-12-27', 70.08, 'type3')) == '1999' # test avec un tuple ('Louis', '1999-12-27', 70.08, 'type3') et doit retourner '1999'
    assert bc.annee(('Louis', '0000-09-01', 67.2, 'type3')) == '0000' # test avec un tuple ('Louis', '0000-09-01', 67.2, 'type3') et doit retourner '0000'
    assert bc.annee(('Louis', '1999-12-27', 70.08, 'type3')) == '1999' # test avec un tuple ('Louis', '1999-12-27', 70.08, 'type3') et doit retourner '1999'

def test_annee_mois():
    assert bc.annee_mois(('Louis', '2024-10-01', 67.2, 'type3')) == '2024-10' # test avec un tuple ('Louis', '2024-10-01', 67.2, 'type3') et doit retourner '2024-10'
    assert bc.annee_mois(('Louis', '2023-09-01', 67.2, 'type3')) == '2023-09' # test avec un tuple ('Louis', '2023-09-01', 67.2, 'type3') et doit retourner '2023-09' 
    assert bc.annee_mois(('Louis', '0000-09-01', 67.2, 'type3')) == '0000-09' # test avec un tuple ('Louis', '0000-09-01', 67.2, 'type3') et doit retourner '0000-09' 
    assert bc.annee_mois(('Louis', '1999-12-27', 70.08, 'type3')) == '1999-12' # test avec un tuple ('Louis', '1999-12-27', 70.08, 'type3') et doit retourner '1999-12'

def test_max_emmission():
    assert bc.max_emmission([]) == None # test avec une liste vide et doit retourner None
    assert bc.max_emmission(bc.liste1) == ('David', '2024-09-29', 23, 'type4')  # test avec une liste non vide liste1 et doit retourner ('David', '2024-09-29', 23, 'type4')
    assert bc.max_emmission(bc.liste2) == ('David', '2024-09-29', 23, 'type4') # test avec une liste non vide liste2 et doit retourner ('David', '2024-09-29', 23, 'type4')
    assert bc.max_emmission(bc.liste3) == ('David', '2024-09-29', 23, 'type4') # test avec une liste non vide liste3 et doit retourner ('David', '2024-09-29', 23, 'type4') 
    assert bc.max_emmission(bc.liste4) == ('David', '2024-09-27', 21, 'type2') # test avec une liste non vide liste4 et doit retourner ('David', '2024-09-27', 21, 'type2')

def test_filtre_par_prenom():
    assert bc.filtre_par_prenom([], 'Louis') == [] # test avec une liste vide et doit retourner une liste vide
    assert bc.filtre_par_prenom([('Louis', '2024-09-01', 67.2, 'type3'), ('David', '2024-09-02', 70.08, 'type3')], 'Louis') == [('Louis', '2024-09-01', 67.2, 'type3')] # test avec une liste non vide et doit retourner une liste avec un seul tuple ('Louis', '2024-09-01', 67.2, 'type3')
    assert bc.filtre_par_prenom(bc.liste1, 'David') == [('David', '2024-09-26', 18, 'type1'), ('David', '2024-09-27', 21, 'type2'), ('David', '2024-09-28', 17, 'type3'), ('David', '2024-09-29', 23, 'type4')] # test avec une liste non vide liste1 et doit retourner une liste avec les tuples de David
    assert bc.filtre_par_prenom(bc.liste2, 'Christophe') == [('Christophe', '2024-09-26', 15, 'type1'), ('Christophe', '2024-09-27', 19, 'type2'),('Christophe', '2024-09-28', 14, 'type3'),('Christophe', '2024-09-29', 20, 'type4'),] # test avec une liste non vide liste2 et doit retourner une liste avec les tuples de Christophe

def test_filtre():
    assert bc.filtre([], 3, 'type1') == [] # test avec une liste vide et doit retourner une liste vide 
    assert bc.filtre(bc.liste3, 1, '2024-09-29') == [('David', '2024-09-29', 23, 'type4'), ('Guillaume', '2024-09-29', 22, 'type4')] # test avec une liste non vide liste3 et doit retourner une liste avec les tuples du 2024-09-29
    assert bc.filtre(bc.liste1, 3, 'type3') == [('Christophe', '2024-09-28', 14, 'type3'),('David', '2024-09-28', 17, 'type3'),('Guillaume', '2024-09-28', 16, 'type3')] # test avec une liste non vide liste1 et doit retourner une liste avec les tuples de type3
    assert bc.filtre(bc.liste2, 2, 17) == [('Guillaume', '2024-09-26', 17, 'type1'),('David', '2024-09-28', 17, 'type3'),] # test avec une liste non vide liste2 et doit retourner une liste avec les tuples de 17
    
def test_cumul_emmissions():
    assert bc.cumul_emmissions([]) == 0 # test avec une liste vide et doit retourner 0
    assert bc.cumul_emmissions(bc.liste4) == 78 # test avec une liste non vide liste4 et doit retourner 78
    assert bc.cumul_emmissions(bc.liste3) == 144 # test avec une liste non vide liste3 et doit retourner 144
    assert bc.cumul_emmissions(bc.liste2) == 222 # test avec une liste non vide liste2 et doit retourner 222

def test_plus_longue_periode_emmissions_decroissantes():
    assert bc.plus_longue_periode_emmissions_decroissantes([]) == 0 # test avec une liste vide et doit retourner 0
    assert bc.plus_longue_periode_emmissions_decroissantes(bc.liste6) == 3 # test avec une liste non vide liste6 et doit retourner 3
    assert bc.plus_longue_periode_emmissions_decroissantes(bc.liste5) == 4 # test avec une liste non vide liste5 et doit retourner 4
    assert bc.plus_longue_periode_emmissions_decroissantes(bc.liste4) == 1 # test avec une liste non vide liste4 et doit retourner 1

def test_est_bien_triee():
    assert bc.est_bien_triee([]) == True # test avec une liste vide et doit retourner True
    assert bc.est_bien_triee([('Louis', '2024-09-01', 67.2, 'type3')]) == True # test avec une liste non vide et doit retourner True
    assert bc.est_bien_triee([('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3')]) == True # test avec une liste non vide et doit retourner True 
    assert bc.est_bien_triee([('Louis', '2024-09-02', 70.08, 'type3'), ('Louis', '2024-09-01', 67.2, 'type3')]) == False # test avec une liste non vide et doit retourner False car les dates ne sont pas triées
    assert bc.est_bien_triee([('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3'), ('Louis', '2024-09-03', 67.2, 'type3')]) == True # test avec une liste non vide et doit retourner True
    assert bc.est_bien_triee([('a', '2024-09-01', 67.2, 'type3'), ('b', '2024-09-03', 70.08, 'type3'), ('a', '2024-09-02', 67.2, 'type3')]) == False # test avec une liste non vide et doit retourner False car les prenoms ne sont pas triés
    
def test_liste_des_types():
    assert bc.liste_des_types([]) == [] # test avec une liste vide et doit retourner une liste vide
    assert bc.liste_des_types([('Louis', '2024-09-01', 67.2, 'type3')]) == ['type3'] # test avec une liste non vide et doit retourner ['type3']
    assert bc.liste_des_types([('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3')]) == ['type3'] # test avec une liste non vide et doit retourner ['type3'] 
    assert bc.liste_des_types([('Louis', '2024-09-01', 67.2, 'type4'), ('Louis', '2024-09-02', 70.08, 'type3')]) == ['type4', 'type3'] # test avec une liste non vide et doit retourner ['type4', 'type3']
    assert bc.liste_des_types(bc.liste1) == ['type1', 'type2', 'type3', 'type4'] # test avec une liste non vide et doit retourner ['type1', 'type2', 'type3', 'type4']

def test_liste_des_personnes():
    assert bc.liste_des_personnes([]) == []
    assert bc.liste_des_personnes([('Louis', '2024-09-01', 67.2, 'type3')]) == ['Louis'] # test avec une liste non vide et doit retourner ['Louis']
    assert bc.liste_des_personnes([('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3')]) == ['Louis'] # test avec une liste non vide et doit retourner ['Louis']
    assert bc.liste_des_personnes([('Louis', '2024-09-01', 67.2, 'type3'), ('David', '2024-09-02', 70.08, 'type3')]) == ['Louis', 'David'] # test avec une liste non vide et doit retourner ['Louis', 'David']

def test_fusionner_activites():
    assert bc.fusionner_activites([], []) == []     # test avec deux listes vides et doit retourner une liste vide
    assert bc.fusionner_activites([('Louis', '2024-09-01', 67.2, 'type3')], [('Louis', '2024-09-02', 70.08, 'type3')]) == [('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3')] # test avec deux listes non vides et doit retourner une liste avec les deux tuples
    assert bc.fusionner_activites([('Louis', '2024-09-02', 70.08, 'type3')], [('Louis', '2024-09-01', 67.2, 'type3')]) == [('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3')] # test avec deux listes non vides et doit retourner une liste avec les deux tuples
    assert bc.fusionner_activites([('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3')], [('Louis', '2024-09-03', 67.2, 'type3')]) == [('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3'), ('Louis', '2024-09-03', 67.2, 'type3')] # test avec deux listes non vides et doit retourner une liste avec les trois tuples
    assert bc.fusionner_activites(bc.liste3, bc.liste4) == bc.liste2 # test avec deux listes non vides et doit retourner une liste avec les tuples de liste2

def test_premiere_apparition_type():
    assert bc.premiere_apparition_type([], 'type1') == None # test avec une liste vide et doit retourner None
    assert bc.premiere_apparition_type([('Lucas', '2024-09-01', 67.2, 'type3')], 'type1') == None # test avec une liste non vide et doit retourner None car le type1 n'existe pas dans la liste 
    assert bc.premiere_apparition_type([('Lucas', '2024-09-01', 67.2, 'type3'), ('Lucas', '2024-09-02', 70.08, 'type3')], 'type3') == '2024-09-01' # test avec une liste non vide et doit retourner '2024-09-01'
    assert bc.premiere_apparition_type([('Lucas', '2024-09-01', 67.2, 'type3'), ('Lucas', '2024-09-02', 70.08, 'type4')], 'type4') == '2024-09-02' # test avec une liste non vide et doit retourner '2024-09-02'
    assert bc.premiere_apparition_type([
        ('Christophe', '2024-09-26', 15, 'type1'),
        ('Christophe', '2024-09-27', 19, 'type2'),
        ('Christophe', '2024-09-28', 14, 'type3'),
        ('Christophe', '2024-09-29', 20, 'type4'),
        ('David', '2024-09-26', 18, 'type1'),
        ('David', '2024-09-27', 21, 'type2'),
        ('David', '2024-09-28', 17, 'type3'),
        ('David', '2024-09-29', 23, 'type4'),
        ('Guillaume', '2024-09-26', 17, 'type1'),
        ('Guillaume', '2024-09-27', 20, 'type2'),
        ('Guillaume', '2024-09-28', 16, 'type3'),
        ('Guillaume', '2024-09-29', 22, 'type4'),
    ], 'type4') == '2024-09-29' # test avec une liste non vide et doit retourner '2024-09-29'

def test_sauver_activites():
    bc.sauver_activites('activites.csv', []) # je sauvergarde dans un fichier activites.csv une liste vide
    assert bc.charger_activites('activites.csv') == [] # je charge le fichier activites.csv et je m'assure que la liste est vide

    bc.sauver_activites('activites.csv', bc.liste1) # je sauvergarde dans un fichier activites.csv la liste1
    assert bc.charger_activites('activites.csv') == bc.liste1 # je charge le fichier activites.csv et je m'assure que la liste est la meme que la liste1

    bc.sauver_activites('activites.csv', bc.liste2) # je sauvergarde dans un fichier activites.csv la liste2
    assert bc.charger_activites('activites.csv') == bc.liste2 # je charge le fichier activites.csv et je m'assure que la liste est la meme que la liste2
    # ce test permet de vérifier si la fonction sauver_activites fonctionne correctement mais aussi si la fonction charger_activites fonctionne correctement

def test_recherche_activite_dichotomique():
    assert bc.recherche_activite_dichotomique('Louis', '2024-09-01', 'type3', []) == None # test avec une liste vide et doit retourner None
    assert bc.recherche_activite_dichotomique('Louis', '2024-09-01', 'type3', [('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3')]) == ('Louis', '2024-09-01', 67.2, 'type3') # test avec une liste non vide et doit retourner ('Louis', '2024-09-01', 67.2, 'type3')
    assert bc.recherche_activite_dichotomique('Louis', '2024-09-02', 'type3', [('Louis', '2024-09-01', 67.2, 'type3'), ('Louis', '2024-09-02', 70.08, 'type3'), ('Louis', '2024-09-03', 67.2, 'type3')]) == ('Louis', '2024-09-02', 70.08, 'type3') # test avec une liste non vide et doit retourner ('Louis', '2024-09-02', 70.08, 'type3')

def test_temps_activite():
    assert bc.temps_activite(('Lucas', '2024-09-01', 67.2, 'type3'), bc.co2_minute) == 67.2/0.96 # test avec un tuple ('Lucas', '2024-09-01', 67.2, 'type3') et doit retourner 67.2/0.96
    assert bc.temps_activite(('Lucas', '2024-09-02', 70.08, 'type5'), bc.co2_minute) == None  # test avec un tuple ('Lucas', '2024-09-02', 70.08, 'type5') et doit retourner None car le type5 n'existe pas dans la liste 
    assert bc.temps_activite(('Lucas', '2024-09-02', 70.08, 'type3'), bc.co2_minute) == 70.08/0.96  # test avec un tuple ('Lucas', '2024-09-02', 70.08, 'type3') et doit retourner 70.08/0.96

def test_cumul_temps_activite():
    assert bc.cumul_temps_activite([], bc.co2_minute) == 0 # test avec une liste vide et doit retourner 0
    assert bc.cumul_temps_activite([('Lucas', '2024-09-01', 67.2, 'type3')], bc.co2_minute) == 67.2/0.96 # test avec une liste non vide [('Lucas', '2024-09-01', 67.2, 'type3')] et doit retourner 67.2/0.96
    assert bc.cumul_temps_activite([('Lucas', '2024-09-01', 67.2, 'type3'), ('Lucas', '2024-09-02', 70.08, 'type3')], bc.co2_minute) == (67.2+70.08)/0.96 # test avec une liste non vide [('Lucas', '2024-09-01', 67.2, 'type3'), ('Lucas', '2024-09-02', 70.08, 'type3')] et doit retourner (67.2+70.08)/0.96

# ---------------------------------------------------------------------------------------------
# Ajoutez ici les tests manquants (vos propres fonctions le cas échéant)
# ---------------------------------------------------------------------------------------------

def test_moyenne_emmissions():
    assert ca.moyenne_emissions([], 'type1') == 0 # test avec une liste vide et doit retourner 0
    assert ca.moyenne_emissions(bc.liste1, 'type1') == 16.666666666666668 # test avec une liste non vide liste1 et doit retourner 16.666666666666668
    assert ca.moyenne_emissions(bc.liste2, 'type2') == 20 # test avec une liste non vide liste2 et doit retourner 20
    assert ca.moyenne_emissions(bc.liste3, 'type5') == 0 # test avec une liste non vide liste3 et doit retourner 0 car le type5 n'existe pas dans la liste

def test_afficher_graphique_emissions_par_personne():
    assert ca.afficher_graphique_emissions_par_personne([]) == None # test avec une liste vide et doit retourner None
    assert ca.afficher_graphique_emissions_par_personne(bc.liste1) == None # test avec une liste non vide liste1 et doit retourner None
    assert ca.afficher_graphique_emissions_par_personne(bc.liste2) == None # test avec une liste non vide liste2 et doit retourner None

def test_max_min_emission_par_activite():
    assert ca.max_min_emission_par_activite([], "type1") ==(None, None, None, None) # test avec une liste vide et doit retourner (None, None, None, None)
    assert ca.max_min_emission_par_activite(bc.liste1, "type1") == ('David', 18.0,'Christophe', 15.0) # test avec une liste non vide liste1 et doit retourner ('David', 18.0,'Cristophe', 15.0)
    assert ca.max_min_emission_par_activite(bc.liste2, "type2") == ('David', 21.0,'Christophe', 19.0) # test avec une liste non vide liste2 et doit retourner ('David', 21.0,'Chistophe', 19.0)
    assert ca.max_min_emission_par_activite(bc.liste3, "type5") == (None, None, None, None) # test avec une liste non vide liste3 et doit retourner (None, None, None, None)
    assert ca.max_min_emission_par_activite([('louis', '2024-09-01', 11.1, 'type3')], "type3") == ('louis', 11.1, 'louis', 11.1) # test avec une liste non vide [('louis', '2024-09-01', 11.1, 'type3')] et doit retourner ('louis', 11.1, 'louis', 11.1)

def test_sauvegarder_emissions_par_prenom():
    assert ca.sauvegarder_emissions_par_prenom("Christophe", "liste_Christophe.csv", bc.liste1) == None # test avec une liste non vide liste1 et doit retourner None
    assert ca.sauvegarder_emissions_par_prenom("David", "liste_David.csv", []) == None # test avec une liste vide et doit retourner None

def test_afficher_temps_activite():
    assert ca.afficher_temps_activite([]) == None # test avec une liste vide et doit retourner None
    assert ca.afficher_temps_activite(bc.liste1) == None # test avec une liste non vide liste1 et doit retourner None
    assert ca.afficher_temps_activite(bc.liste2) == None # test avec une liste non vide liste2 et doit retourner None

def test_activite_la_plus_polluante():
    assert ca.activite_la_plus_polluante([], "Louis") == None # test avec une liste vide et doit retourner None
    assert ca.activite_la_plus_polluante(bc.liste1, "David") == ('type4', 23.0) # test avec une liste non vide liste1 et doit retourner ('type4', 23.0)
    assert ca.activite_la_plus_polluante(bc.liste2, "Christophe") == ('type4', 20.0) # test avec une liste non vide liste2 et doit retourner ('type4', 20.0)
    assert ca.activite_la_plus_polluante(bc.liste3, "Louis") == None # test avec une liste non vide liste3 et doit retourner None

def test_pourcentage_activite_type():
    assert ca.pourcentage_activite_type([], "type1") == 0 # test avec une liste vide et doit retourner 0
    assert ca.pourcentage_activite_type(bc.liste1, "type1") == 100.0 # test avec une liste non vide liste1 et doit retourner 100.0
    assert ca.pourcentage_activite_type(bc.liste2, "type2") == 100.0 # test avec une liste non vide liste2 et doit retourner 100.0
    assert ca.pourcentage_activite_type(bc.liste3, "type5") == 0 # test avec une liste non vide liste3 et doit retourner 0
