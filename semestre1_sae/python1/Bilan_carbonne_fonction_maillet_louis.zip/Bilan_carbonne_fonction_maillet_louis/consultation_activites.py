import bilan_carbone as bc 
def afficher_menu(titre, liste_options):
    """ 
    Affiche un menu avec un titre et une liste d'options.
    Args:
        titre (str): Le titre du menu.
        liste_options (list): La liste des options du menu.
    """

    ligne = '+' + '-' * (len(titre) + 2) + '+'
    print(ligne)
    print("| " + titre + " |")
    print(ligne)
    for i in range(len(liste_options)):
        print(f"{i+1} -> {liste_options[i]}")
    print(ligne)
def demander_nombre(message, borne_max):
    
    """
    Demande à l'utilisateur de saisir un nombre et vérifie qu'il est valide.
    Args:
        message (str): Le message à afficher pour demander le nombre.
        borne_max (int): La valeur maximale que le nombre peut prendre.
    Returns:
        int: Le nombre saisi par l'utilisateur qui est valide.
    """

    a = input(message)
    if not a.isdecimal() or int(a) != float(a) or int(a) < 1 or int(a) > borne_max:
        return None
    else :
        return int(a)

def menu(titre, liste_options):
    afficher_menu(titre, liste_options)
    demande = demander_nombre("Entrez votre choix [1-"+str(len(liste_options))+']:', len(liste_options))
    return demande


def programme_principal():
    liste_options = ["Charger un fichier",
                     "Afficher le maximum et le minimum des émissions pour une activité",
                     "Afficher la moyenne des émissions pour une activité",
                     "Afficher le maximum des émissions",
                     "Rechercher une activité avec un prénom, une date et un type",
                     "Afficher les émissions d'une personne",
                     "Afficher un graphique des émissions par personne",
                     "Sauvegarder les émissions d'une personne",
                     "Afficher le temps total des activités pour chaque personne",
                     "Afficher le pourcentage de personnes pratiquant une activité de type donné",
                     "Afficher l'activité la plus polluante d'une personne",

                     "Quitter"]
    liste_activite = None
    while True:
        print("\n")
        rep = menu("MENU DE MON APPLICATION", liste_options)
        if rep is None:
            print("Cette option n'existe pas")

        elif rep == 1:
            print("Vous avez choisi", liste_options[rep - 1])
            while True:
                try:
                    nom_fic = input("Entrez le nom du fichier à charger : ")
                    liste_activite = bc.charger_activites(nom_fic)
                    print("Fichier chargé avec succès")
                    break
                except:
                    print("Fichier non trouvé. Veuillez réessayer.")

        elif rep in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]:
            if liste_activite is None:
                print("Aucune activité chargée. Veuillez charger un fichier d'abord.")
            else:
                if rep == 2:
                    print("Vous avez choisi", liste_options[rep - 1])
                    activite = input("Entrez le nom de l'activité : ")
                    max_min = max_min_emission_par_activite(liste_activite, activite)
                    print(f"Pour l'activité {activite} :")
                    print(f"La personne avec les émissions les plus élevées est {max_min[0]} avec {max_min[1]}")
                    print(f"La personne avec les émissions les plus faibles est {max_min[2]} avec {max_min[3]}")

                elif rep == 3:
                    print("Vous avez choisi", liste_options[rep - 1])
                    activite = input("Entrez le nom de l'activité : ")
                    moyenne = moyenne_emissions(liste_activite, activite)
                    print(f"La moyenne des émissions pour l'activité {activite} est de {moyenne}")

                elif rep == 4:
                    print("Vous avez choisi", liste_options[rep - 1])
                    print(bc.max_emmission(liste_activite))
                
                elif rep == 5:
                    print("Vous avez choisi", liste_options[rep - 1])
                    prenom = input("Entrez le prénom : ")
                    jour = input("Entrez le jour (YYYY-MM-DD) : ")
                    type = input("Entrez le type : ")
                    activite = bc.recherche_activite_dichotomique(prenom, jour, type, liste_activite)
                    if activite is not None:
                        print(f"L'activité {activite} est présente dans le fichier.")
                    else:
                        print(f"L'activité {activite} n'est pas présente dans le fichier.")

                elif rep == 6:
                    print("Vous avez choisi", liste_options[rep - 1])
                    prenom = input("Entrez le prénom : ")
                    emissions = bc.filtre_par_prenom(liste_activite, prenom)
                    if emissions is not None:
                        cpt = 0
                        for emission in emissions:
                            cpt += emission[2]
                        print(f"Les émissions de {prenom} sont de {cpt} grammes")
                        emission = input("voulez vous afficher les emissions de CO2 de cette personne? (O/N) : ")
                        if emission == "O":
                            for emission in emissions:
                                print(f"Le {emission[1]}, {prenom} a émis {emission[2]} grammes de CO2 pour l'activité {emission[3]}")

                        moyenne = input("voulez vous afficher la moyenne des emissions de CO2 de cette personne? (O/N) : ")
                        if moyenne == "O":
                            print(f"La moyenne des emissions de {prenom} est de {cpt/len(emissions)}")

                        activite = input("voulez vous afficher les activités de cette personne? (O/N) : ")
                        if activite == "O":
                            liste_activite_prenom = []
                            for emission in emissions:
                                if emission[3] not in liste_activite_prenom and prenom == emission[0]:
                                    liste_activite_prenom.append(emission[3])
                            print(f"Les activités de {prenom} sont : {liste_activite_prenom}")
                    else:
                        print(f"Le prénom {prenom} n'est pas présent dans le fichier.")

                elif rep == 7:
                    print("Vous avez choisi", liste_options[rep - 1])
                    print("\n")
                    afficher_graphique_emissions_par_personne(liste_activite)

                elif rep == 8:
                    print("Vous avez choisi", liste_options[rep - 1])
                    prenom = input("Entrez le prénom : ")
                    nom_fichier = input("Entrez le nom du fichier où sauvegarder les émissions : ")
                    sauvegarder_emissions_par_prenom(prenom, nom_fichier, liste_activite)

                elif rep == 9:
                    print("Vous avez choisi", liste_options[rep - 1])
                    afficher_temps_activite(liste_activite)

                elif rep == 10:
                    print("Vous avez choisi", liste_options[rep - 1])
                    type = input("Entrez le type d'activité : ")
                    if type in ["type1", "type2", "type3", "type4"]:
                        pourcentage = pourcentage_activite_type(liste_activite, type)
                        print(f"Le pourcentage de personnes pratiquant une activité de type {type} est de {pourcentage//1}%")
                    else:
                        print("Type d'activité invalide.")
                
                elif rep == 11:
                    print("Vous avez choisi", liste_options[rep - 1])
                    prenom = input("Entrez le prénom : ")
                    activite = activite_la_plus_polluante(liste_activite, prenom)
                    if activite is not None:
                        print(f"L'activité la plus polluante de {prenom} est {activite[0]} avec {activite[1]} grammes de CO2.")
                    else:
                        print(f"Aucune activité trouvée pour {prenom}.")
        else:
            break
        print("\n")
        input("Appuyer sur Entrée pour continuer")
    print("Merci au revoir!")
    
def moyenne_emissions(liste_activite, type):
    """
    Calcule la moyenne des émissions pour une activité donnée.
    Args:
        liste_activite (list): La liste des activités.
        activite (str): Le nom de l'activité.
    Returns:
        float: La moyenne des émissions pour l'activité donnée."""
    total = 0
    nb = 0
    for ligne in liste_activite:
        if ligne[3] == type:
            total += float(ligne[2])
            nb += 1
    if nb != 0:
        return total / nb
    else:
        return 0
    
def max_min_emission_par_activite(liste_activite, type):
    """
    Recherche la personne avec les émissions les plus élevées et les plus faibles pour une activité donnée.
    Args:
        liste_activite (list): La liste des activités.
        activite (str): Le nom de l'activité.
    Returns:
        tuple: Un tuple contenant le nom de la personne avec les émissions les plus élevées et les plus faibles pour l'activité donnée, ainsi que les valeurs des émissions.
    """
    max_emission = None
    min_emission = None
    nom_max = None
    nom_min = None
    for ligne in liste_activite:
        if ligne[3] == type:
            emission = float(ligne[2])
            if max_emission is None or emission > max_emission:
                max_emission = emission
                nom_max = ligne[0]
            if min_emission is None or emission < min_emission:
                min_emission = emission
                nom_min = ligne[0]
    return (nom_max, max_emission, nom_min, min_emission)

def afficher_graphique_emissions_par_personne(liste_activite):
    """
    Affiche un graphique du co2 émis par personne.
    Args:
        liste_activite (list): La liste des activités.
    """
    liste_personnes = bc.liste_des_personnes(liste_activite)
    liste_emissions = []
    for personne in liste_personnes:
        emissions_filtre = bc.filtre_par_prenom(liste_activite, personne)
        total = 0
        for emission in emissions_filtre:
            total += emission[2]
        liste_emissions.append((personne, total))

    print("Graphique des émissions par personne:")
    for tuple in liste_emissions:
        personne = tuple[0]
        emission = tuple[1]
        barre = '*' * int(emission / 100)
        print(f"{personne:>15}: {barre} ce qui represente {emission//1} grammes de CO2")
    
def sauvegarder_emissions_par_prenom(prenom, nom_fichier, liste_activite):
    """
    Sauvegarde les émissions de CO2 d'une personne dans un fichier.
    Args:
        prenom (str): Le prénom de la personne.
        nom_fichier (str): Le nom du fichier où sauvegarder les émissions.
        liste_activite (list): La liste des activités.
    """
    emissions = bc.filtre_par_prenom(liste_activite, prenom)
    if emissions != []:
        a = bc.sauver_activites(nom_fichier, emissions)
        print(f"Les émissions de {prenom} ont été sauvegardées dans le fichier {nom_fichier}.")
    else:
        print(f"Aucune émission trouvée pour {prenom}.")

def afficher_temps_activite(liste_activite):
    """
    Affiche le temps total des activités pour chaque personne.
    Args:
        liste_activite (list): La liste des activités.
    """
    liste_personnes = bc.liste_des_personnes(liste_activite)
    for personne in liste_personnes:
        activites_filtre = bc.filtre_par_prenom(liste_activite, personne)
        temps_total = bc.cumul_temps_activite(activites_filtre, bc.co2_minute)
        print(f"{personne} a passé un total de {temps_total} minutes sur ses activités.")

def activite_la_plus_polluante(liste_activite, prenom):
    """
    Retourne l'activité la plus polluante d'une personne.
    Args:
        liste_activite (list): La liste des activités.
        prenom (str): Le prénom de la personne.
    Returns:
        tuple: L'activité la plus polluante et la quantité de CO2 émise.
    """
    liste = bc.filtre_par_prenom(liste_activite, prenom)
    if liste == []:
        return None
    max_emission = liste[0]
    for emission in liste:
        if emission[2] > max_emission[2]:
            max_emission = emission
    return max_emission[3],max_emission[2]

def pourcentage_activite_type(liste_activite, type):
    """
    Calcule le pourcentage de personnes pratiquant une activité de type donné.
    Args:
        liste_activite (list): La liste des activités.
        type (str): Le type d'activité.
    Returns:
        float: Le pourcentage de personnes pratiquant l'activité de type donne"
    """
    cpt_personne_qui_fait_activite = 0
    lst_personne = []
    for tuple in liste_activite:
        if tuple[3] == type and tuple[0] not in lst_personne:
            cpt_personne_qui_fait_activite += 1
            lst_personne.append(tuple[0])
    if cpt_personne_qui_fait_activite == 0:
        return 0
    return cpt_personne_qui_fait_activite / len(bc.liste_des_personnes(liste_activite)) * 100

#programme_principal()