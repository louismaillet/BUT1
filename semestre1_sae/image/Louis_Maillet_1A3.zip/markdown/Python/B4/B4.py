from PIL import Image

i = Image.open("IUT-Orleans.bmp")
sortie = Image.new(i.mode, i.size)

for x in range(i.size[0]):
    for y in range(i.size[1]):
        rouge, vert, bleu = i.getpixel((x, y))
        intensite = rouge**2 + vert**2 + bleu**2

        if intensite > (255**2 * 3 / 2):
            sortie.putpixel((x, y), (255, 255, 255))
        else:
            sortie.putpixel((x, y), (0, 0, 0))

sortie.save("Imageout3.bmp")
